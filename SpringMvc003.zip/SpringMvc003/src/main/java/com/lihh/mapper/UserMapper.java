package com.lihh.mapper;

import com.lihh.pojo.Account;

import java.util.List;

public interface UserMapper {
    List<Account> allUser();
}
