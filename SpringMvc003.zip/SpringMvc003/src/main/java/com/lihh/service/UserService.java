package com.lihh.service;

import com.lihh.pojo.Account;

import java.util.List;

public interface UserService {
    List<Account> allUser();
}
