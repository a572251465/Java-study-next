package com.lihh.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.lihh.pojo.Emp;

public interface EmpService extends IService<Emp> {
}
